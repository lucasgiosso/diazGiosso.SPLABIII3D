// import Anuncio_Auto from "./anuncio_auto.js"
// import { getLocalStorageData } from "./localStorage.js";

// var localData;

// window.addEventListener("load", () => {
//     localData = getLocalStorageData(Anuncio_Auto.getMainKey());
//     console.log(localData);

//     localData.forEach(item => {
//         createCards(item);
//     });
// });

// function createCards(item) {
//     // Create the article
//     const article = document.querySelector("#articles");
//     const div = document.createElement("div");
//     div.className = "cards";

//     //create the h2 tag
//     const title = document.createElement("h2");
//     // create the paragraph tag
//     const description = document.createElement("p");
//     const price = document.createElement("p");
//     price.id = "price";

//     // create the paragraph tag
//     const doors = document.createElement("p");
//     doors.style.display = "inline";

//     // create the paragraph tag
//     const km = document.createElement("p");
//     km.style.display = "inline";
//     // create the paragraph tag
//     const horsePower = document.createElement("p");
//     horsePower.style.display = "inline";    

//     const doorsIcon = document.createElement("img");
//     doorsIcon.src = "./media/icon/car-door.png";
//     doorsIcon.style.margin = "5px";

//     const kmIcon = document.createElement("img");
//     kmIcon.src = "./media/icon/speedometer.png";
//     kmIcon.style.margin = "5px";

//     const horsePowerIcon = document.createElement("img");
//     horsePowerIcon.src = "./media/icon/engine.png";
//     horsePowerIcon.style.margin = "5px";
//     const boton = document.createElement("button");
//     boton.id = "button";
//     boton.className = "formButtons";        
//     boton.innerHTML = "Ver Vehiculo";

//     // Append all the childs created
//     title.innerHTML = item.title;
//     description.innerHTML = item.description;
//     price.innerHTML = "$" + item.price;
//     doors.innerHTML = item.doors;
//     km.innerHTML = item.kilometers;
//     horsePower.innerHTML = item.horsePower;
//     div.appendChild(title);
//     div.appendChild(description);
//     div.appendChild(price);
//     div.appendChild(doorsIcon);
//     div.appendChild(doors);
//     div.appendChild(kmIcon);
//     div.appendChild(km);
//     div.appendChild(horsePowerIcon);
//     div.appendChild(horsePower);
//     div.appendChild(boton);

//     article.appendChild(div);
// }

import { getObjectsFetchForCards } from "./jsFetch/Read.js";

export const createMainCards = () => {
    const article = document.querySelector("#articles");
    getObjectsFetchForCards((data) => {
        console.log("createMainCards", data);
        if(article != null) {
            data.forEach(item => {
                article.appendChild(createCards(item));
            });
        }
    });
}

/**
 * Event listener for Load.
 */
window.addEventListener("load", () => {
    console.log('Dentro de index');
    createMainCards();
});


const createMainDiv = () => {
    const div = document.createElement("div");
    div.setAttribute("class", "cards col-md-4");
    div.setAttribute("style", "width: 18rem;");
    return div;
}


const createDivCardBody = () => {
    let divCardBody = document.createElement("div");
    divCardBody.setAttribute("class", "card-body");
    return divCardBody;
}

const createTitle = (item) => {
    //create the h2 tag
    const title = document.createElement("h5");
    title.setAttribute("class", "card-title");
    title.innerHTML = item.title;
    return title;
}


const createDescription = (item) => {
    const description = document.createElement("p");
    description.setAttribute("class", "card-text");
    description.innerHTML = item.description;
    return description;
}

const createPrice = (item) => {
    const price = document.createElement("p");
    price.setAttribute("class", "card-text");
    price.id = "price";
    price.innerHTML = "$" + item.price;
    return price;
}

const createPartsParagraph = (item) => {
    let doors = document.createElement("p");
    doors.style.display = "inline";
    doors.innerHTML = item.doors;
    return doors;
}


const createIcon = (path) => {
    let doorsIcon = document.createElement("img");
    doorsIcon.src = `${path}`;
    doorsIcon.style.margin = "5px";
    return doorsIcon;
}


const createButton = () => {
    let button = document.createElement("button");
    button.setAttribute("class", "btn btn-danger");
    button.id = "button";
    button.className = "formButtons";        
    button.innerHTML = "Ver Vehiculos";
    return button;
}


function createCards(item) {
    // Create the article
    const div = createMainDiv();
    const divCardBody = createDivCardBody();
    divCardBody.appendChild(createTitle(item));
    divCardBody.appendChild(createDescription(item));
    divCardBody.appendChild(createPrice(item));
    divCardBody.appendChild(createIcon("./media/icon/car-door.png"));
    divCardBody.appendChild(createPartsParagraph(item));
    divCardBody.appendChild(createIcon("./media/icon/speedometer.png"));
    divCardBody.appendChild(createPartsParagraph(item));
    divCardBody.appendChild(createIcon("./media/icon/engine.png"));
    divCardBody.appendChild(createPartsParagraph(item));
    divCardBody.appendChild(createButton());
    div.appendChild(divCardBody);
    
    return div;
}