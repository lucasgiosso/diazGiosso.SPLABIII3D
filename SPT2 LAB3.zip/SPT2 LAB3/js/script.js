
import { updateTable} from "./dynamicTable.js";
import { myForm, updateForm, hideUnhideButtons } from "./myForm.js";
import { createObjectFetch } from "./jsFetch/Create.js";
import { updateObjectFetch } from "./jsFetch/Update.js";
import { getObjectsFetch, getObjectsFetchCB } from "./jsFetch/Read.js";
import { deleteObjectFetch } from "./jsFetch/Delete.js";
import { checkBoxHandler, filterAddsHandler } from "./Filter.js";

let myLocalData;
const $myNewForm = document.forms[0];
export let filteredAds=[];
export let temporalListAds=[];
export const myCheckBox =  document.querySelectorAll(".myCheck");
export const myAverage = document.getElementById("Average");
const buttonDelete = document.getElementById("buttonDelete");
const buttonModify = document.getElementById("buttonModify");
const buttonCreate = document.getElementById("buttonSubmit");
const buttonCancel = document.getElementById("buttonCancel");

window.addEventListener("load", () => {
  // myLocalData = getLocalStorageData(Anuncio_Auto.getMainKey());
  getObjectsFetchCB((data)=>{
    filteredAds = data;
    temporalListAds = data;
  updateTable(myLocalData);
});

myCheckBox.forEach((element)=> element.addEventListener("click",checkBoxHandler));
buttonDelete.addEventListener("click", DeleteHandlerEvent);
buttonModify.addEventListener("click", ModifyHandlerEvent);
buttonCreate.addEventListener("click", CreateHandlerEvent);
buttonCancel.addEventListener("click", CancelHandlerEvent);
});

window.addEventListener("click", (ev) => {
  if(ev.target.matches('td')){
      hideUnhideButtons(false);
      updateForm($myNewForm.elements, ev.target.parentElement);
  }
});


  const CreateHandlerEvent = () => {

    const myData = myForm($myNewForm.elements);
    if(myData.id === ''){
      createObjectFetch(myData);
      hideUnhideButtons(true);
      $myNewForm.reset();
    }
  }
  
  const CancelHandlerEvent = () => {

    hideUnhideButtons(true);
  }

  const DeleteHandlerEvent = () => {

    console.log('Id to delete: ');
    let idToDelete = $myNewForm.elements.idForm.value;
    console.log(idToDelete);
    deleteObjectFetch(idToDelete);
    hideUnhideButtons(true);
    $myNewForm.reset();
  }

  const ModifyHandlerEvent = () => 
{
  const myData = myForm($myNewForm.elements);
  updateObjectFetch(myData.id, myData);
  hideUnhideButtons(true);
  $myNewForm.reset();
}

window.addEventListener("change", (ev) => 
{
  if(ev.target.matches('#FTransaction')){

    filterAddsHandler(ev, filteredAds, temporalListAds);
  }
});


