import Anuncio from './anuncio.js';

export default class Anuncio_Auto extends Anuncio {

    static getLocalStorage() {
        let anuncios = [];
        let anuncio = JSON.parse(localStorage.getItem(AnuncioChild.getMainKey()));
        if (anuncio != null) {
            anuncios.push(anuncio);
        }
        return anuncios;
    }

    constructor(id, title, transaction, description, price, doors, kilometers, horsePower) {
        super(id, title, transaction, description, price);
        this.doors = doors;
        this.kilometers = kilometers;
        this.horsePower = horsePower;
    }

    static getMainKey() {
        return 'anuncio';
    }
}