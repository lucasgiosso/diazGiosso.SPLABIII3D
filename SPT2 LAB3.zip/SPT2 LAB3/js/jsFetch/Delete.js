import { ToggleSpinner } from "../Spinner.js";
import { URL } from "../BackData.js";

const deleteObjectFetch = (id) => {

    const option = {
        method:"DELETE"
    };

    ToggleSpinner(true);
    // envio la peticion.
    fetch(`${URL}/${id}`, option)
    // respuesta de la peticion.
    .then((res)=>{
        console.log(res);
        // valido que la respuesta sea correcta.
        // retorna una promesa, el retorno del retorno de res.
        // si falla, envio una promesa rechazada.
        return res.ok ? res.json() : Promise.reject(res);
    })
    .then((data)=>{
        alert(`Object borrado`);
    })
    // al fallar, lo catcheo y muestro.
    .catch((err)=>{
        console.error(err);
    })
    .finally(()=>{
        ToggleSpinner(false);
    })
}

export {deleteObjectFetch};