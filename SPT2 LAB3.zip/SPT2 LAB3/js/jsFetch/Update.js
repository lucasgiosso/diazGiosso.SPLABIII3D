import { ToggleSpinner } from "../Spinner.js";
import { URL } from "../BackData.js";

const updateObjectFetch = (id,object)=>{
   const options  =  {
       method:"PUT",
       headers:{
           "Content-Type":"application/json; charset=utf-8"
       },
       body:JSON.stringify(object)
   };
   //ToggleSpinner(true);
   fetch(`${URL}/${id}`, options)
   .then((res)=>{
       // valido que la respuesta sea correcta.
       // retorna una promesa, el retorno del retorno de res.
       // si falla, envio una promesa rechazada.
       return res.ok ? res.json() : Promise.reject(res);
   })
   .then((data)=>{
       console.log(data);
       alert(`Object [${data.id}] [${data.title} ${data.description}] updated sucessfully`);
   })
   .catch((error)=>{
       console.error(`Error: ${error.status} : ${error.status}`);
   })
   .finally(()=>{
       ToggleSpinner(false);
   });
};

export { updateObjectFetch };