import { ToggleSpinner } from "../Spinner.js";
import { URL } from "../BackData.js";

const createObjectFetch = (myObject) => {

   const option = {
       method:"POST",
       headers:{
           "Content-Type":"application/json"
       },
       body:JSON.stringify(myObject)
   };

   ToggleSpinner(true);
   // envio la peticion.
   fetch(URL, option)
   // respuesta de la peticion.
   .then((res)=>{
       console.log(res);
       // valido que la respuesta sea correcta.
       // retorna una promesa, el retorno del retorno de res.
       // si falla, envio una promesa rechazada.
       return res.ok ? res.json() : Promise.reject(res);
   })
   .then((data)=>{
       alert(`Object [${data.id}] [${data.title} ${data.description}] creado correctamente`);
   })
   // al fallar, lo catcheo y muestro.
   .catch((err)=>{
       console.error(`Error: ${err}`);
   })
   .finally(()=>{
       ToggleSpinner(false);
   })
}

export {createObjectFetch};