import { ToggleSpinner } from "../Spinner.js";
 import { updateTable } from "../dynamicTable.js";
 import { URL } from "../BackData.js";
 
 const getObjectsFetch = () => {
    ToggleSpinner(true);
    // envio la peticion.
    fetch(URL)
    // respuesta de la peticion.
    .then((res)=>{
        // valido que la respuesta sea correcta.
        // retorna una promesa, el retorno del retorno de res.
        // si falla, envio una promesa rechazada.
        return res.ok ? res.json() : Promise.reject(res);
    })
    .then((data)=>{
        console.log('Get Objects Fetch:');
        console.log(data);
        updateTable(data);
    })
    // al fallar, lo catcheo y muestro.
    .catch((err)=>{
        console.error(err);
    })
    .finally((data)=>{
        ToggleSpinner(false);
    })
}

const getObjectsFetchCB = (callback) => {
    ToggleSpinner(true);
    // envio la peticion.
    fetch(URL)
    // respuesta de la peticion.
    .then((res)=>{
        // valido que la respuesta sea correcta.
        // retorna una promesa, el retorno del retorno de res.
        // si falla, envio una promesa rechazada.
        return res.ok ? res.json() : Promise.reject(res);
    })
    .then((data)=>{
        console.log(data);
        callback(data);
    })
    // al fallar, lo catcheo y muestro.
    .catch((err)=>{
        //console.error(err);
    })
    .finally((data)=>{
        ToggleSpinner(false);
    })
}

const getObjectsFetchForCards = (callback) => {
    ToggleSpinner(true);
    // envio la peticion.
    fetch(URL)
    // respuesta de la peticion.
    .then((res)=>{
        // valido que la respuesta sea correcta.
        // retorna una promesa, el retorno del retorno de res.
        // si falla, envio una promesa rechazada.
        return res.ok ? res.json() : Promise.reject(res);
    })
    .then((data)=>{
        console.log(data);
        callback(data);
    })

    // al fallar, lo catcheo y muestro.
    .catch((err)=>{
        console.error(err);
    })
    .finally((data)=>{
        ToggleSpinner(false);
    })
}

const getObjectFetch = (id) => {
    ToggleSpinner(true);
    // envio la peticion.
    fetch(`${URL}/${id}`)
    // respuesta de la peticion.
    .then((res)=>{
        console.log(res);

        // valido que la respuesta sea correcta.
        // retorna una promesa, el retorno del retorno de res.
        // si falla, envio una promesa rechazada.
        return res.ok ? res.json() : Promise.reject(res);
    })
    .then((data)=>{
        console.log(data);
        alert(`Object [${data.id}] [${data.title} ${data.description}] readed sucessfully`)
        return data;
    })
    // al fallar, lo catcheo y muestro.
    .catch((err)=>{
        console.error(err);
    })
    .finally(()=>{
        ToggleSpinner(false);
    })
}

export { getObjectsFetch, getObjectFetch, getObjectsFetchForCards, getObjectsFetchCB };