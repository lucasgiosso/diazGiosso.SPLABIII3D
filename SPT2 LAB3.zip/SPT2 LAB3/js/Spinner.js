//  export default function toggleSpinner()
//  {
//      const div = document.getElementById('spinnerCont');
//     const divAds = document.getElementById('dynamicTable');
    
//     if (div.style.display == 'none') {
//         div.style.display = 'flex';
//       divAds.style.display = 'none';
//     }
//    else {
//        div.style.display = 'none';
//          divAds.style.display = 'block';
//    }
//  }

export const divSpinner = document.getElementById("spinner");

const getSpinner = () => {

    console.log(divSpinner);
    let spinner = document.createElement('img');
    spinner.setAttribute('src', './media/wheelspinner.gif');
    spinner.setAttribute('alt', 'Spinner');
    //divSpinner.appendChild( spinner);
}

const clearSpinner = () => {

    while(divSpinner.hasChildNodes()){
        divSpinner.removeChild(divSpinner.firstChild);
    }
}

export const ToggleSpinner = (bool) => {
    if (bool){
        getSpinner();
    }else{
        clearSpinner();
    }
}
